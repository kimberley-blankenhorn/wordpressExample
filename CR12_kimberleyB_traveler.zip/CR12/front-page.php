<?php get_header(); ?>



<div class="container-fluid">
    <div class="row">
    
    <div class="card bg-dark text-white border-0">
  <img src="<?php echo get_template_directory_uri(); ?>/image/everest.jpg" class="card-img" alt="...">
  <div class="card-img-overlay">
    <h1 class="card-title text-white">Mount Everest Travel Agency</h1>
    <h3 class="card-text">Your journey starts here....</h3>

  </div>
</div>
    
    
    
    </div>

</div>

<?php get_footer(); ?>
