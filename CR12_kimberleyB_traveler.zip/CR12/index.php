<?php get_header(); ?>

<div id="feature">
    <img src="<?php echo get_template_directory_uri(); ?>/image/snow2.jpg" class="img-fluid mb-5" alt="...">
</div>


    
    <div class="page container-fluid">

        <div class="row justify-content-center">
            <div class="col-md-7 col-12">
            <?php if(have_posts()) : ?>
            <!--  If there are posts available  -->

            <?php while(have_posts()) : the_post(); ?>
            <!-- if there are posts, iterate the posts in the loop
-->
            
            <div class="card mb-2 mx-auto shadow p-3 mb-5 bg-white rounded">
                <?php $image =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID ), 'full'); ?>
                <img src="<?php echo $image[0];?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php the_title(); ?></h5>
                    <p> <?php the_author(); ?></p>
                    <p><?php the_time('M j, Y G:i'); ?></p>
                    <p class="card-text"><?php the_excerpt(); ?></p>
                    <a href="<?php the_permalink(); ?>" class="btn btn-info">Go To Post</a>
                </div>
            </div>


            <?php endwhile; ?>
            <!--end the while loop-->

            <?php else :?>
            <!-- if no posts are found then: -->

            <p>No posts found</p> <!-- no posts found displayed -->
            <?php endif; ?>
            <!-- end if -->
            </div>
            
            <div class="sidebar col-4 d-none d-md-block">
            <?php get_sidebar(); ?>
            </div>


        </div>
    
    </div>




<?php get_footer(); ?>