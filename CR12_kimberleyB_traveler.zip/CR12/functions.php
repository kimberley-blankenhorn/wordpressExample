<?php 

function theme_files(){


wp_enqueue_style('bootstrap-css', get_template_directory_uri().'/css/bootstrap.css');
wp_enqueue_style('my style sheet', get_template_directory_uri().'/style.css');
wp_enqueue_script('bootstrap-js', get_template_directory_uri(). '/js/bootstrap.js', array(), '1.0', true);
// true means to load the script at the bottom...false means to load it at the top
}

add_action('wp_enqueue_scripts', 'theme_files');

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

	register_nav_menus( array(
    'primary' => __( 'Top Menu', 'THEMENAME' ),
) );
}
add_action( 'after_setup_theme', 'register_navwalker' );


//////////////////////////////////////////////////
///// Activate Thumbnails/Featured Image /////////
///////////////////////////////////////////////

add_theme_support('post-thumbnails');

function set_excerpt_length(){
	return 20; //the number of words you want displayed
}
add_filter('excerpt_length','set_excerpt_length');

//Widget - sidebar
function wpb_init_widgets(){
	register_sidebar(array(
		'name' => 'Sidebar',
		'id' => 'sidebar',
		'before_widget' => '<div class="sidebar-module text-danger">',
		'after_widget' => '</div>',
		'before_title' => '<h4>',
		'after_title' => '</h4>'
		 ));
 }
 add_action('widgets_init', 'wpb_init_widgets');


?>